# 不限 - 不限 代码实操案例

# 说明：这是一个通用练习模板。
# 你可以根据 不限 的具体知识点继续补充实现。

def practice_example():
    course = '不限'
    topic = '不限'
    print(f'正在练习 {course} 中的 {topic}')
    print('请补充一个和该知识点相关的代码案例')

if __name__ == '__main__':
    practice_example()
